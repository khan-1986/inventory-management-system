<div class="sidebar content-box" style="display: block;">
                <ul class="nav">
                    <!-- Main menu -->
                    <li class="current"><a href="dashboard.php"><i class="glyphicon glyphicon-home"></i> Dashboard</a></li>
                    <li><a href="http://localhost/Management_System/user/add_user.php"><i class="glyphicon glyphicon-user"></i> User</a></li>
                    <li><a href="http://localhost/Management_System/add_branch.php"> Branch</a></li>
                    <li><a href="add_factory.php"><i class="glyphicon glyphicon-eye-open"></i> Factory</a></li>
                    <li><a href="#">Customer</a>
                    <li><a href="#">Stock</a></li>
                    <li><a href="products.php">Product Entry</a></li>
                    <li><a href="product_stock.php">Product Stock</a></li>
                    <li><a href="add_order.php">Add Order</a></li>
                    <li><a href="all_orders.php"><i class="glyphicon glyphicon-eye-open"></i> All Orders</a></li>
                    <li><a href="sale.php">Sale/Return</a></li>
                    <li><a href="expense.php">Income/Expense</a></li>
                    <li><a href="#">Backups</a></li>
                    <li><a href="login/logout.php"><i class="glyphicon glyphicon-log-out"></i> Logout</a></li>
                </ul>
             </div>