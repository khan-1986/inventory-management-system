<?php
session_start();
if(!isset($_SESSION['login'])){
	header('location: login/Login.php');
}else{
	include('dashboard.php');
}
?>